g++ $1.cpp -o $1 -O2 -W -Wall
